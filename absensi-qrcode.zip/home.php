<?php  
    include"header.php";
    include"sidebar.php";
?>
        <!-- MAIN -->
        <div class="main">
            <!-- MAIN CONTENT -->
            <div class="main-content">
                <div class="container-fluid">
                    <!-- OVERVIEW -->
                    <div class="panel panel-headline">
                        <div class="panel-heading">
                            <h3 class="panel-title">Beranda</h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="text-center">
                                    <h2>Selamat Datang</h2>
                                    <h2>di</h2>
                                    <img src="assets/img/LOGO-UNDHIRA-fix.png" />
                                    <h2>Sistem Informasi Absensi</h2>
                                    <h2>dengan QR-CODE</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END OVERVIEW -->
                </div>
            </div>
            <!-- END MAIN CONTENT -->
        </div>
        <!-- END MAIN -->
<?php include"footer.php"; ?>